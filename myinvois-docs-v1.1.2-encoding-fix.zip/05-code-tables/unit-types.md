<!-- source: https://sdk.myinvois.hasil.gov.my/codes/unit-types/ -->

# Unit of measurement

List of unit of measurement types allowed as part of the document line information as part of the document submission.

[Codes](README.md)

# Overview

Unit of measurement types are used as part of the document lines in document submission. This code table is following the UN/ECE Recommendation 20, Revision 17 (2021) as per [here](https://unece.org/trade/documents/revision-17-annexes-i-iii).

# List

## Unit Types

| Code | Name |
| --- | --- |
| 10 | group |
| 11 | outfit |
| 13 | ration |
| 14 | shot |
| 15 | stick, military |
| 1I | fixed rate |
| 20 | twenty foot container |
| 21 | forty foot container |
| 22 | decilitre per gram |
| 23 | gram per cubic centimetre |
| 24 | theoretical pound |
| 25 | gram per square centimetre |
| 27 | theoretical ton |
| 28 | kilogram per square metre |
| 2A | radian per second |
| 2B | radian per second squared |
| 2C | roentgen |
| 2G | volt AC |
| 2H | volt DC |
| 2I | British thermal unit (international table) per hour |
| 2J | cubic centimetre per second |
| 2K | cubic foot per hour |
| 2L | cubic foot per minute |
| 2M | centimetre per second |
| 2N | decibel |
| 2P | kilobyte |
| 2Q | kilobecquerel |
| 2R | kilocurie |
| 2U | megagram |
| 2X | metre per minute |
| 2Y | milliroentgen |
| 2Z | millivolt |
| 33 | kilopascal square metre per gram |
| 34 | kilopascal per millimetre |
| 35 | millilitre per square centimetre second |
| 37 | ounce per square foot |
| 38 | ounce per square foot per 0,01inch |
| 3B | megajoule |
| 3C | manmonth |
| 40 | millilitre per second |
| 41 | millilitre per minute |
| 4C | centistokes |
| 4G | microlitre |
| 4H | micrometre (micron) |
| 4K | milliampere |
| 4L | megabyte |
| 4M | milligram per hour |
| 4N | megabecquerel |
| 4O | microfarad |
| 4P | newton per metre |
| 4Q | ounce inch |
| 4R | ounce foot |
| 4T | picofarad |
| 4U | pound per hour |
| 4W | ton (US) per hour |
| 4X | kilolitre per hour |
| 56 | sitas |
| 57 | mesh |
| 58 | net kilogram |
| 59 | part per million |
| 5A | barrel (US) per minute |
| 5B | batch |
| 5E | MMSCF/day |
| 5J | hydraulic horse power |
| 60 | percent weight |
| 61 | part per billion (US) |
| 74 | millipascal |
| 77 | milli-inch |
| 80 | pound per square inch absolute |
| 81 | henry |
| 85 | foot pound-force |
| 87 | pound per cubic foot |
| 89 | poise |
| 91 | stokes |
| A10 | ampere square metre per joule second |
| A11 | angstrom |
| A12 | astronomical unit |
| A13 | attojoule |
| A14 | barn |
| A15 | barn per electronvolt |
| A16 | barn per steradian electronvolt |
| A17 | barn per steradian |
| A18 | becquerel per kilogram |
| A19 | becquerel per cubic metre |
| A2 | ampere per centimetre |
| A20 | British thermal unit (international table) per second square foot degree Rankine |
| A21 | British thermal unit (international table) per pound degree Rankine |
| A22 | British thermal unit (international table) per second foot degree Rankine |
| A23 | British thermal unit (international table) per hour square foot degree Rankine |
| A24 | candela per square metre |
| A26 | coulomb metre |
| A27 | coulomb metre squared per volt |
| A28 | coulomb per cubic centimetre |
| A29 | coulomb per cubic metre |
| A3 | ampere per millimetre |
| A30 | coulomb per cubic millimetre |
| A31 | coulomb per kilogram second |
| A32 | coulomb per mole |
| A33 | coulomb per square centimetre |
| A34 | coulomb per square metre |
| A35 | coulomb per square millimetre |
| A36 | cubic centimetre per mole |
| A37 | cubic decimetre per mole |
| A38 | cubic metre per coulomb |
| A39 | cubic metre per kilogram |
| A4 | ampere per square centimetre |
| A40 | cubic metre per mole |
| A41 | ampere per square metre |
| A42 | curie per kilogram |
| A43 | deadweight tonnage |
| A44 | decalitre |
| A45 | decametre |
| A47 | decitex |
| A48 | degree Rankine |
| A49 | denier |
| A5 | ampere square metre |
| A53 | electronvolt |
| A54 | electronvolt per metre |
| A55 | electronvolt square metre |
| A56 | electronvolt square metre per kilogram |
| A59 | 8-part cloud cover |
| A6 | ampere per square metre kelvin squared |
| A68 | exajoule |
| A69 | farad per metre |
| A7 | ampere per square millimetre |
| A70 | femtojoule |
| A71 | femtometre |
| A73 | foot per second squared |
| A74 | foot pound-force per second |
| A75 | freight ton |
| A76 | gal |
| A8 | ampere second |
| A84 | gigacoulomb per cubic metre |
| A85 | gigaelectronvolt |
| A86 | gigahertz |
| A87 | gigaohm |
| A88 | gigaohm metre |
| A89 | gigapascal |
| A9 | rate |
| A90 | gigawatt |
| A91 | gon |
| A93 | gram per cubic metre |
| A94 | gram per mole |
| A95 | gray |
| A96 | gray per second |
| A97 | hectopascal |
| A98 | henry per metre |
| A99 | bit |
| AA | ball |
| AB | bulk pack |
| ACR | acre |
| ACT | activity |
| AD | byte |
| AE | ampere per metre |
| AH | additional minute |
| AI | average minute per call |
| AK | fathom |
| AL | access line |
| AMH | ampere hour |
| AMP | ampere |
| ANN | year |
| APZ | troy ounce or apothecary ounce |
| AQ | anti-hemophilic factor (AHF) unit |
| AS | assortment |
| ASM | alcoholic strength by mass |
| ASU | alcoholic strength by volume |
| ATM | standard atmosphere |
| AWG | american wire gauge |
| AY | assembly |
| AZ | British thermal unit (international table) per pound |
| B1 | barrel (US) per day |
| B10 | bit per second |
| B11 | joule per kilogram kelvin |
| B12 | joule per metre |
| B13 | joule per square metre |
| B14 | joule per metre to the fourth power |
| B15 | joule per mole |
| B16 | joule per mole kelvin |
| B17 | credit |
| B18 | joule second |
| B19 | digit |
| B20 | joule square metre per kilogram |
| B21 | kelvin per watt |
| B22 | kiloampere |
| B23 | kiloampere per square metre |
| B24 | kiloampere per metre |
| B25 | kilobecquerel per kilogram |
| B26 | kilocoulomb |
| B27 | kilocoulomb per cubic metre |
| B28 | kilocoulomb per square metre |
| B29 | kiloelectronvolt |
| B3 | batting pound |
| B30 | gibibit |
| B31 | kilogram metre per second |
| B32 | kilogram metre squared |
| B33 | kilogram metre squared per second |
| B34 | kilogram per cubic decimetre |
| B35 | kilogram per litre |
| B4 | barrel, imperial |
| B41 | kilojoule per kelvin |
| B42 | kilojoule per kilogram |
| B43 | kilojoule per kilogram kelvin |
| B44 | kilojoule per mole |
| B45 | kilomole |
| B46 | kilomole per cubic metre |
| B47 | kilonewton |
| B48 | kilonewton metre |
| B49 | kiloohm |
| B50 | kiloohm metre |
| B52 | kilosecond |
| B53 | kilosiemens |
| B54 | kilosiemens per metre |
| B55 | kilovolt per metre |
| B56 | kiloweber per metre |
| B57 | light year |
| B58 | litre per mole |
| B59 | lumen hour |
| B60 | lumen per square metre |
| B61 | lumen per watt |
| B62 | lumen second |
| B63 | lux hour |
| B64 | lux second |
| B66 | megaampere per square metre |
| B67 | megabecquerel per kilogram |
| B68 | gigabit |
| B69 | megacoulomb per cubic metre |
| B7 | cycle |
| B70 | megacoulomb per square metre |
| B71 | megaelectronvolt |
| B72 | megagram per cubic metre |
| B73 | meganewton |
| B74 | meganewton metre |
| B75 | megaohm |
| B76 | megaohm metre |
| B77 | megasiemens per metre |
| B78 | megavolt |
| B79 | megavolt per metre |
| B8 | joule per cubic metre |
| B80 | gigabit per second |
| B81 | reciprocal metre squared reciprocal second |
| B82 | inch per linear foot |
| B83 | metre to the fourth power |
| B84 | microampere |
| B85 | microbar |
| B86 | microcoulomb |
| B87 | microcoulomb per cubic metre |
| B88 | microcoulomb per square metre |
| B89 | microfarad per metre |
| B90 | microhenry |
| B91 | microhenry per metre |
| B92 | micronewton |
| B93 | micronewton metre |
| B94 | microohm |
| B95 | microohm metre |
| B96 | micropascal |
| B97 | microradian |
| B98 | microsecond |
| B99 | microsiemens |
| BAR | bar [unit of pressure] |
| BB | base box |
| BFT | board foot |
| BHP | brake horse power |
| BIL | billion (EUR) |
| BLD | dry barrel (US) |
| BLL | barrel (US) |
| BP | hundred board foot |
| BPM | beats per minute |
| BQL | becquerel |
| BTU | British thermal unit (international table) |
| BUA | bushel (US) |
| BUI | bushel (UK) |
| C0 | call |
| C10 | millifarad |
| C11 | milligal |
| C12 | milligram per metre |
| C13 | milligray |
| C14 | millihenry |
| C15 | millijoule |
| C16 | millimetre per second |
| C17 | millimetre squared per second |
| C18 | millimole |
| C19 | mole per kilogram |
| C20 | millinewton |
| C21 | kibibit |
| C22 | millinewton per metre |
| C23 | milliohm metre |
| C24 | millipascal second |
| C25 | milliradian |
| C26 | millisecond |
| C27 | millisiemens |
| C28 | millisievert |
| C29 | millitesla |
| C3 | microvolt per metre |
| C30 | millivolt per metre |
| C31 | milliwatt |
| C32 | milliwatt per square metre |
| C33 | milliweber |
| C34 | mole |
| C35 | mole per cubic decimetre |
| C36 | mole per cubic metre |
| C37 | kilobit |
| C38 | mole per litre |
| C39 | nanoampere |
| C40 | nanocoulomb |
| C41 | nanofarad |
| C42 | nanofarad per metre |
| C43 | nanohenry |
| C44 | nanohenry per metre |
| C45 | nanometre |
| C46 | nanoohm metre |
| C47 | nanosecond |
| C48 | nanotesla |
| C49 | nanowatt |
| C50 | neper |
| C51 | neper per second |
| C52 | picometre |
| C53 | newton metre second |
| C54 | newton metre squared per kilogram squared |
| C55 | newton per square metre |
| C56 | newton per square millimetre |
| C57 | newton second |
| C58 | newton second per metre |
| C59 | octave |
| C60 | ohm centimetre |
| C61 | ohm metre |
| C62 | one |
| C63 | parsec |
| C64 | pascal per kelvin |
| C65 | pascal second |
| C66 | pascal second per cubic metre |
| C67 | pascal second per metre |
| C68 | petajoule |
| C69 | phon |
| C7 | centipoise |
| C70 | picoampere |
| C71 | picocoulomb |
| C72 | picofarad per metre |
| C73 | picohenry |
| C74 | kilobit per second |
| C75 | picowatt |
| C76 | picowatt per square metre |
| C78 | pound-force |
| C79 | kilovolt ampere hour |
| C8 | millicoulomb per kilogram |
| C80 | rad |
| C81 | radian |
| C82 | radian square metre per mole |
| C83 | radian square metre per kilogram |
| C84 | radian per metre |
| C85 | reciprocal angstrom |
| C86 | reciprocal cubic metre |
| C87 | reciprocal cubic metre per second |
| C88 | reciprocal electron volt per cubic metre |
| C89 | reciprocal henry |
| C9 | coil group |
| C90 | reciprocal joule per cubic metre |
| C91 | reciprocal kelvin or kelvin to the power minus one |
| C92 | reciprocal metre |
| C93 | reciprocal square metre |
| C94 | reciprocal minute |
| C95 | reciprocal mole |
| C96 | reciprocal pascal or pascal to the power minus one |
| C97 | reciprocal second |
| C99 | reciprocal second per metre squared |
| CCT | carrying capacity in metric ton |
| CDL | candela |
| CEL | degree Celsius |
| CEN | hundred |
| CG | card |
| CGM | centigram |
| CKG | coulomb per kilogram |
| CLF | hundred leave |
| CLT | centilitre |
| CMK | square centimetre |
| CMQ | cubic centimetre |
| CMT | centimetre |
| CNP | hundred pack |
| CNT | cental (UK) |
| COU | coulomb |
| CTG | content gram |
| CTM | metric carat |
| CTN | content ton (metric) |
| CUR | curie |
| CWA | hundred pound (cwt) / hundred weight (US) |
| CWI | hundred weight (UK) |
| D03 | kilowatt hour per hour |
| D04 | lot [unit of weight] |
| D1 | reciprocal second per steradian |
| D10 | siemens per metre |
| D11 | mebibit |
| D12 | siemens square metre per mole |
| D13 | sievert |
| D15 | sone |
| D16 | square centimetre per erg |
| D17 | square centimetre per steradian erg |
| D18 | metre kelvin |
| D19 | square metre kelvin per watt |
| D2 | reciprocal second per steradian metre squared |
| D20 | square metre per joule |
| D21 | square metre per kilogram |
| D22 | square metre per mole |
| D23 | pen gram (protein) |
| D24 | square metre per steradian |
| D25 | square metre per steradian joule |
| D26 | square metre per volt second |
| D27 | steradian |
| D29 | terahertz |
| D30 | terajoule |
| D31 | terawatt |
| D32 | terawatt hour |
| D33 | tesla |
| D34 | tex |
| D36 | megabit |
| D41 | tonne per cubic metre |
| D42 | tropical year |
| D43 | unified atomic mass unit |
| D44 | var |
| D45 | volt squared per kelvin squared |
| D46 | volt - ampere |
| D47 | volt per centimetre |
| D48 | volt per kelvin |
| D49 | millivolt per kelvin |
| D5 | kilogram per square centimetre |
| D50 | volt per metre |
| D51 | volt per millimetre |
| D52 | watt per kelvin |
| D53 | watt per metre kelvin |
| D54 | watt per square metre |
| D55 | watt per square metre kelvin |
| D56 | watt per square metre kelvin to the fourth power |
| D57 | watt per steradian |
| D58 | watt per steradian square metre |
| D59 | weber per metre |
| D6 | roentgen per second |
| D60 | weber per millimetre |
| D61 | minute [unit of angle] |
| D62 | second [unit of angle] |
| D63 | book |
| D65 | round |
| D68 | number of words |
| D69 | inch to the fourth power |
| D73 | joule square metre |
| D74 | kilogram per mole |
| D77 | megacoulomb |
| D78 | megajoule per second |
| D80 | microwatt |
| D81 | microtesla |
| D82 | microvolt |
| D83 | millinewton metre |
| D85 | microwatt per square metre |
| D86 | millicoulomb |
| D87 | millimole per kilogram |
| D88 | millicoulomb per cubic metre |
| D89 | millicoulomb per square metre |
| D91 | rem |
| D93 | second per cubic metre |
| D94 | second per cubic metre radian |
| D95 | joule per gram |
| DAA | decare |
| DAD | ten day |
| DAY | day |
| DB | dry pound |
| DBM | Decibel-milliwatts |
| DBW | Decibel watt |
| DD | degree [unit of angle] |
| DEC | decade |
| DG | decigram |
| DJ | decagram |
| DLT | decilitre |
| DMA | cubic decametre |
| DMK | square decimetre |
| DMO | standard kilolitre |
| DMQ | cubic decimetre |
| DMT | decimetre |
| DN | decinewton metre |
| DPC | dozen piece |
| DPR | dozen pair |
| DPT | displacement tonnage |
| DRA | dram (US) |
| DRI | dram (UK) |
| DRL | dozen roll |
| DT | dry ton |
| DTN | decitonne |
| DWT | pennyweight |
| DZN | dozen |
| DZP | dozen pack |
| E01 | newton per square centimetre |
| E07 | megawatt hour per hour |
| E08 | megawatt per hertz |
| E09 | milliampere hour |
| E10 | degree day |
| E12 | mille |
| E14 | kilocalorie (international table) |
| E15 | kilocalorie (thermochemical) per hour |
| E16 | million Btu(IT) per hour |
| E17 | cubic foot per second |
| E18 | tonne per hour |
| E19 | ping |
| E20 | megabit per second |
| E21 | shares |
| E22 | TEU |
| E23 | tyre |
| E25 | active unit |
| E27 | dose |
| E28 | air dry ton |
| E30 | strand |
| E31 | square metre per litre |
| E32 | litre per hour |
| E33 | foot per thousand |
| E34 | gigabyte |
| E35 | terabyte |
| E36 | petabyte |
| E37 | pixel |
| E38 | megapixel |
| E39 | dots per inch |
| E4 | gross kilogram |
| E40 | part per hundred thousand |
| E41 | kilogram-force per square millimetre |
| E42 | kilogram-force per square centimetre |
| E43 | joule per square centimetre |
| E44 | kilogram-force metre per square centimetre |
| E45 | milliohm |
| E46 | kilowatt hour per cubic metre |
| E47 | kilowatt hour per kelvin |
| E48 | service unit |
| E49 | working day |
| E50 | accounting unit |
| E51 | job |
| E52 | run foot |
| E53 | test |
| E54 | trip |
| E55 | use |
| E56 | well |
| E57 | zone |
| E58 | exabit per second |
| E59 | exbibyte |
| E60 | pebibyte |
| E61 | tebibyte |
| E62 | gibibyte |
| E63 | mebibyte |
| E64 | kibibyte |
| E65 | exbibit per metre |
| E66 | exbibit per square metre |
| E67 | exbibit per cubic metre |
| E68 | gigabyte per second |
| E69 | gibibit per metre |
| E70 | gibibit per square metre |
| E71 | gibibit per cubic metre |
| E72 | kibibit per metre |
| E73 | kibibit per square metre |
| E74 | kibibit per cubic metre |
| E75 | mebibit per metre |
| E76 | mebibit per square metre |
| E77 | mebibit per cubic metre |
| E78 | petabit |
| E79 | petabit per second |
| E80 | pebibit per metre |
| E81 | pebibit per square metre |
| E82 | pebibit per cubic metre |
| E83 | terabit |
| E84 | terabit per second |
| E85 | tebibit per metre |
| E86 | tebibit per cubic metre |
| E87 | tebibit per square metre |
| E88 | bit per metre |
| E89 | bit per square metre |
| E90 | reciprocal centimetre |
| E91 | reciprocal day |
| E92 | cubic decimetre per hour |
| E93 | kilogram per hour |
| E94 | kilomole per second |
| E95 | mole per second |
| E96 | degree per second |
| E97 | millimetre per degree Celcius metre |
| E98 | degree Celsius per kelvin |
| E99 | hectopascal per bar |
| EA | each |
| EB | electronic mail box |
| EQ | equivalent gallon |
| F01 | bit per cubic metre |
| F02 | kelvin per kelvin |
| F03 | kilopascal per bar |
| F04 | millibar per bar |
| F05 | megapascal per bar |
| F06 | poise per bar |
| F07 | pascal per bar |
| F08 | milliampere per inch |
| F10 | kelvin per hour |
| F11 | kelvin per minute |
| F12 | kelvin per second |
| F13 | slug |
| F14 | gram per kelvin |
| F15 | kilogram per kelvin |
| F16 | milligram per kelvin |
| F17 | pound-force per foot |
| F18 | kilogram square centimetre |
| F19 | kilogram square millimetre |
| F20 | pound inch squared |
| F21 | pound-force inch |
| F22 | pound-force foot per ampere |
| F23 | gram per cubic decimetre |
| F24 | kilogram per kilomol |
| F25 | gram per hertz |
| F26 | gram per day |
| F27 | gram per hour |
| F28 | gram per minute |
| F29 | gram per second |
| F30 | kilogram per day |
| F31 | kilogram per minute |
| F32 | milligram per day |
| F33 | milligram per minute |
| F34 | milligram per second |
| F35 | gram per day kelvin |
| F36 | gram per hour kelvin |
| F37 | gram per minute kelvin |
| F38 | gram per second kelvin |
| F39 | kilogram per day kelvin |
| F40 | kilogram per hour kelvin |
| F41 | kilogram per minute kelvin |
| F42 | kilogram per second kelvin |
| F43 | milligram per day kelvin |
| F44 | milligram per hour kelvin |
| F45 | milligram per minute kelvin |
| F46 | milligram per second kelvin |
| F47 | newton per millimetre |
| F48 | pound-force per inch |
| F49 | rod [unit of distance] |
| F50 | micrometre per kelvin |
| F51 | centimetre per kelvin |
| F52 | metre per kelvin |
| F53 | millimetre per kelvin |
| F54 | milliohm per metre |
| F55 | ohm per mile (statute mile) |
| F56 | ohm per kilometre |
| F57 | milliampere per pound-force per square inch |
| F58 | reciprocal bar |
| F59 | milliampere per bar |
| F60 | degree Celsius per bar |
| F61 | kelvin per bar |
| F62 | gram per day bar |
| F63 | gram per hour bar |
| F64 | gram per minute bar |
| F65 | gram per second bar |
| F66 | kilogram per day bar |
| F67 | kilogram per hour bar |
| F68 | kilogram per minute bar |
| F69 | kilogram per second bar |
| F70 | milligram per day bar |
| F71 | milligram per hour bar |
| F72 | milligram per minute bar |
| F73 | milligram per second bar |
| F74 | gram per bar |
| F75 | milligram per bar |
| F76 | milliampere per millimetre |
| F77 | pascal second per kelvin |
| F78 | inch of water |
| F79 | inch of mercury |
| F80 | water horse power |
| F81 | bar per kelvin |
| F82 | hectopascal per kelvin |
| F83 | kilopascal per kelvin |
| F84 | millibar per kelvin |
| F85 | megapascal per kelvin |
| F86 | poise per kelvin |
| F87 | volt per litre minute |
| F88 | newton centimetre |
| F89 | newton metre per degree |
| F90 | newton metre per ampere |
| F91 | bar litre per second |
| F92 | bar cubic metre per second |
| F93 | hectopascal litre per second |
| F94 | hectopascal cubic metre per second |
| F95 | millibar litre per second |
| F96 | millibar cubic metre per second |
| F97 | megapascal litre per second |
| F98 | megapascal cubic metre per second |
| F99 | pascal litre per second |
| FAH | degree Fahrenheit |
| FAR | farad |
| FBM | fibre metre |
| FC | thousand cubic foot |
| FF | hundred cubic metre |
| FH | micromole |
| FIT | failures in time |
| FL | flake ton |
| FNU | Formazin nephelometric unit |
| FOT | foot |
| FP | pound per square foot |
| FR | foot per minute |
| FS | foot per second |
| FTK | square foot |
| FTQ | cubic foot |
| G01 | pascal cubic metre per second |
| G04 | centimetre per bar |
| G05 | metre per bar |
| G06 | millimetre per bar |
| G08 | square inch per second |
| G09 | square metre per second kelvin |
| G10 | stokes per kelvin |
| G11 | gram per cubic centimetre bar |
| G12 | gram per cubic decimetre bar |
| G13 | gram per litre bar |
| G14 | gram per cubic metre bar |
| G15 | gram per millilitre bar |
| G16 | kilogram per cubic centimetre bar |
| G17 | kilogram per litre bar |
| G18 | kilogram per cubic metre bar |
| G19 | newton metre per kilogram |
| G2 | US gallon per minute |
| G20 | pound-force foot per pound |
| G21 | cup [unit of volume] |
| G23 | peck |
| G24 | tablespoon (US) |
| G25 | teaspoon (US) |
| G26 | stere |
| G27 | cubic centimetre per kelvin |
| G28 | litre per kelvin |
| G29 | cubic metre per kelvin |
| G3 | Imperial gallon per minute |
| G30 | millilitre per kelvin |
| G31 | kilogram per cubic centimetre |
| G32 | ounce (avoirdupois) per cubic yard |
| G33 | gram per cubic centimetre kelvin |
| G34 | gram per cubic decimetre kelvin |
| G35 | gram per litre kelvin |
| G36 | gram per cubic metre kelvin |
| G37 | gram per millilitre kelvin |
| G38 | kilogram per cubic centimetre kelvin |
| G39 | kilogram per litre kelvin |
| G40 | kilogram per cubic metre kelvin |
| G41 | square metre per second bar |
| G42 | microsiemens per centimetre |
| G43 | microsiemens per metre |
| G44 | nanosiemens per centimetre |
| G45 | nanosiemens per metre |
| G46 | stokes per bar |
| G47 | cubic centimetre per day |
| G48 | cubic centimetre per hour |
| G49 | cubic centimetre per minute |
| G50 | gallon (US) per hour |
| G51 | litre per second |
| G52 | cubic metre per day |
| G53 | cubic metre per minute |
| G54 | millilitre per day |
| G55 | millilitre per hour |
| G56 | cubic inch per hour |
| G57 | cubic inch per minute |
| G58 | cubic inch per second |
| G59 | milliampere per litre minute |
| G60 | volt per bar |
| G61 | cubic centimetre per day kelvin |
| G62 | cubic centimetre per hour kelvin |
| G63 | cubic centimetre per minute kelvin |
| G64 | cubic centimetre per second kelvin |
| G65 | litre per day kelvin |
| G66 | litre per hour kelvin |
| G67 | litre per minute kelvin |
| G68 | litre per second kelvin |
| G69 | cubic metre per day kelvin |
| G70 | cubic metre per hour kelvin |
| G71 | cubic metre per minute kelvin |
| G72 | cubic metre per second kelvin |
| G73 | millilitre per day kelvin |
| G74 | millilitre per hour kelvin |
| G75 | millilitre per minute kelvin |
| G76 | millilitre per second kelvin |
| G77 | millimetre to the fourth power |
| G78 | cubic centimetre per day bar |
| G79 | cubic centimetre per hour bar |
| G80 | cubic centimetre per minute bar |
| G81 | cubic centimetre per second bar |
| G82 | litre per day bar |
| G83 | litre per hour bar |
| G84 | litre per minute bar |
| G85 | litre per second bar |
| G86 | cubic metre per day bar |
| G87 | cubic metre per hour bar |
| G88 | cubic metre per minute bar |
| G89 | cubic metre per second bar |
| G90 | millilitre per day bar |
| G91 | millilitre per hour bar |
| G92 | millilitre per minute bar |
| G93 | millilitre per second bar |
| G94 | cubic centimetre per bar |
| G95 | litre per bar |
| G96 | cubic metre per bar |
| G97 | millilitre per bar |
| G98 | microhenry per kiloohm |
| G99 | microhenry per ohm |
| GB | gallon (US) per day |
| GBQ | gigabecquerel |
| GDW | gram, dry weight |
| GE | pound per gallon (US) |
| GF | gram per metre (gram per 100 centimetres) |
| GFI | gram of fissile isotope |
| GGR | great gross |
| GIA | gill (US) |
| GIC | gram, including container |
| GII | gill (UK) |
| GIP | gram, including inner packaging |
| GJ | gram per millilitre |
| GL | gram per litre |
| GLD | dry gallon (US) |
| GLI | gallon (UK) |
| GLL | gallon (US) |
| GM | gram per square metre |
| GO | milligram per square metre |
| GP | milligram per cubic metre |
| GQ | microgram per cubic metre |
| GRM | gram |
| GRN | grain |
| GRO | gross |
| GT | gross ton |
| GV | gigajoule |
| GWH | gigawatt hour |
| H03 | henry per kiloohm |
| H04 | henry per ohm |
| H05 | millihenry per kiloohm |
| H06 | millihenry per ohm |
| H07 | pascal second per bar |
| H08 | microbecquerel |
| H09 | reciprocal year |
| H10 | reciprocal hour |
| H11 | reciprocal month |
| H12 | degree Celsius per hour |
| H13 | degree Celsius per minute |
| H14 | degree Celsius per second |
| H15 | square centimetre per gram |
| H16 | square decametre |
| H18 | square hectometre |
| H19 | cubic hectometre |
| H20 | cubic kilometre |
| H21 | blank |
| H22 | volt square inch per pound-force |
| H23 | volt per inch |
| H24 | volt per microsecond |
| H25 | percent per kelvin |
| H26 | ohm per metre |
| H27 | degree per metre |
| H28 | microfarad per kilometre |
| H29 | microgram per litre |
| H30 | square micrometre (square micron) |
| H31 | ampere per kilogram |
| H32 | ampere squared second |
| H33 | farad per kilometre |
| H34 | hertz metre |
| H35 | kelvin metre per watt |
| H36 | megaohm per kilometre |
| H37 | megaohm per metre |
| H38 | megaampere |
| H39 | megahertz kilometre |
| H40 | newton per ampere |
| H41 | newton metre watt to the power minus 0,5 |
| H42 | pascal per metre |
| H43 | siemens per centimetre |
| H44 | teraohm |
| H45 | volt second per metre |
| H46 | volt per second |
| H47 | watt per cubic metre |
| H48 | attofarad |
| H49 | centimetre per hour |
| H50 | reciprocal cubic centimetre |
| H51 | decibel per kilometre |
| H52 | decibel per metre |
| H53 | kilogram per bar |
| H54 | kilogram per cubic decimetre kelvin |
| H55 | kilogram per cubic decimetre bar |
| H56 | kilogram per square metre second |
| H57 | inch per two pi radiant |
| H58 | metre per volt second |
| H59 | square metre per newton |
| H60 | cubic metre per cubic metre |
| H61 | millisiemens per centimetre |
| H62 | millivolt per minute |
| H63 | milligram per square centimetre |
| H64 | milligram per gram |
| H65 | millilitre per cubic metre |
| H66 | millimetre per year |
| H67 | millimetre per hour |
| H68 | millimole per gram |
| H69 | picopascal per kilometre |
| H70 | picosecond |
| H71 | percent per month |
| H72 | percent per hectobar |
| H73 | percent per decakelvin |
| H74 | watt per metre |
| H75 | decapascal |
| H76 | gram per millimetre |
| H77 | module width |
| H79 | French gauge |
| H80 | rack unit |
| H81 | millimetre per minute |
| H82 | big point |
| H83 | litre per kilogram |
| H84 | gram millimetre |
| H85 | reciprocal week |
| H87 | piece |
| H88 | megaohm kilometre |
| H89 | percent per ohm |
| H90 | percent per degree |
| H91 | percent per ten thousand |
| H92 | percent per one hundred thousand |
| H93 | percent per hundred |
| H94 | percent per thousand |
| H95 | percent per volt |
| H96 | percent per bar |
| H98 | percent per inch |
| H99 | percent per metre |
| HA | hank |
| HAD | Piece Day |
| HAR | Hectare |
| HBA | hectobar |
| HBX | hundred boxes |
| HC | hundred count |
| HDW | hundred kilogram, dry weight |
| HEA | head |
| HGM | hectogram |
| HH | hundred cubic foot |
| HIU | hundred international unit |
| HKM | hundred kilogram, net mass |
| HLT | hectolitre |
| HM | mile per hour (statute mile) |
| HMO | Piece Month |
| HMQ | million cubic metre |
| HMT | hectometre |
| HPA | hectolitre of pure alcohol |
| HTZ | hertz |
| HUR | hour |
| IA | inch pound (pound inch) |
| IE | person |
| INH | inch |
| INK | square inch |
| INQ | cubic inch |
| ISD | international sugar degree |
| IU | inch per second |
| IUG | international unit per gram |
| IV | inch per second squared |
| J10 | percent per millimetre |
| J12 | per mille per psi |
| J13 | degree API |
| J14 | degree Baume (origin scale) |
| J15 | degree Baume (US heavy) |
| J16 | degree Baume (US light) |
| J17 | degree Balling |
| J18 | degree Brix |
| J19 | degree Fahrenheit hour square foot per British thermal unit (thermochemical) |
| J2 | joule per kilogram |
| J20 | degree Fahrenheit per kelvin |
| J21 | degree Fahrenheit per bar |
| J22 | degree Fahrenheit hour square foot per British thermal unit (international table) |
| J23 | degree Fahrenheit per hour |
| J24 | degree Fahrenheit per minute |
| J25 | degree Fahrenheit per second |
| J26 | reciprocal degree Fahrenheit |
| J27 | degree Oechsle |
| J28 | degree Rankine per hour |
| J29 | degree Rankine per minute |
| J30 | degree Rankine per second |
| J31 | degree Twaddell |
| J32 | micropoise |
| J33 | microgram per kilogram |
| J34 | microgram per cubic metre kelvin |
| J35 | microgram per cubic metre bar |
| J36 | microlitre per litre |
| J38 | baud |
| J39 | British thermal unit (mean) |
| J40 | British thermal unit (international table) foot per hour  square foot degree Fahrenheit |
| J41 | British thermal unit (international table) inch per hour square  foot degree Fahrenheit |
| J42 | British thermal unit (international table) inch per second square  foot degree Fahrenheit |
| J43 | British thermal unit (international table) per pound degree Fahrenheit |
| J44 | British thermal unit (international table) per minute |
| J45 | British thermal unit (international table) per second |
| J46 | British thermal unit (thermochemical) foot per hour square  foot degree Fahrenheit |
| J47 | British thermal unit (thermochemical) per hour |
| J48 | British thermal unit (thermochemical) inch per hour square  foot degree Fahrenheit |
| J49 | British thermal unit (thermochemical) inch per second  square foot degree Fahrenheit |
| J50 | British thermal unit (thermochemical) per pound degree Fahrenheit |
| J51 | British thermal unit (thermochemical) per minute |
| J52 | British thermal unit (thermochemical) per second |
| J53 | coulomb square metre per kilogram |
| J54 | megabaud |
| J55 | watt second |
| J56 | bar per bar |
| J57 | barrel (UK petroleum) |
| J58 | barrel (UK petroleum) per minute |
| J59 | barrel (UK petroleum) per day |
| J60 | barrel (UK petroleum) per hour |
| J61 | barrel (UK petroleum) per second |
| J62 | barrel (US petroleum) per hour |
| J63 | barrel (US petroleum) per second |
| J64 | bushel (UK) per day |
| J65 | bushel (UK) per hour |
| J66 | bushel (UK) per minute |
| J67 | bushel (UK) per second |
| J68 | bushel (US dry) per day |
| J69 | bushel (US dry) per hour |
| J70 | bushel (US dry) per minute |
| J71 | bushel (US dry) per second |
| J72 | centinewton metre |
| J73 | centipoise per kelvin |
| J74 | centipoise per bar |
| J75 | calorie (mean) |
| J76 | calorie (international table) per gram degree Celsius |
| J78 | calorie (thermochemical) per centimetre second degree Celsius |
| J79 | calorie (thermochemical) per gram degree Celsius |
| J81 | calorie (thermochemical) per minute |
| J82 | calorie (thermochemical) per second |
| J83 | clo |
| J84 | centimetre per second kelvin |
| J85 | centimetre per second bar |
| J87 | cubic centimetre per cubic metre |
| J90 | cubic decimetre per day |
| J91 | cubic decimetre per cubic metre |
| J92 | cubic decimetre per minute |
| J93 | cubic decimetre per second |
| J95 | ounce (UK fluid) per day |
| J96 | ounce (UK fluid) per hour |
| J97 | ounce (UK fluid) per minute |
| J98 | ounce (UK fluid) per second |
| J99 | ounce (US fluid) per day |
| JE | joule per kelvin |
| JK | megajoule per kilogram |
| JM | megajoule per cubic metre |
| JNT | pipeline joint |
| JOU | joule |
| JPS | hundred metre |
| JWL | number of jewels |
| K1 | kilowatt demand |
| K10 | ounce (US fluid) per hour |
| K11 | ounce (US fluid) per minute |
| K12 | ounce (US fluid) per second |
| K13 | foot per degree Fahrenheit |
| K14 | foot per hour |
| K15 | foot pound-force per hour |
| K16 | foot pound-force per minute |
| K17 | foot per psi |
| K18 | foot per second degree Fahrenheit |
| K19 | foot per second psi |
| K2 | kilovolt ampere reactive demand |
| K20 | reciprocal cubic foot |
| K21 | cubic foot per degree Fahrenheit |
| K22 | cubic foot per day |
| K23 | cubic foot per psi |
| K26 | gallon (UK) per day |
| K27 | gallon (UK) per hour |
| K28 | gallon (UK) per second |
| K3 | kilovolt ampere reactive hour |
| K30 | gallon (US liquid) per second |
| K31 | gram-force per square centimetre |
| K32 | gill (UK) per day |
| K33 | gill (UK) per hour |
| K34 | gill (UK) per minute |
| K35 | gill (UK) per second |
| K36 | gill (US) per day |
| K37 | gill (US) per hour |
| K38 | gill (US) per minute |
| K39 | gill (US) per second |
| K40 | standard acceleration of free fall |
| K41 | grain per gallon (US) |
| K42 | horsepower (boiler) |
| K43 | horsepower (electric) |
| K45 | inch per degree Fahrenheit |
| K46 | inch per psi |
| K47 | inch per second degree Fahrenheit |
| K48 | inch per second psi |
| K49 | reciprocal cubic inch |
| K50 | kilobaud |
| K51 | kilocalorie (mean) |
| K52 | kilocalorie (international table) per hour metre degree Celsius |
| K53 | kilocalorie (thermochemical) |
| K54 | kilocalorie (thermochemical) per minute |
| K55 | kilocalorie (thermochemical) per second |
| K58 | kilomole per hour |
| K59 | kilomole per cubic metre kelvin |
| K6 | kilolitre |
| K60 | kilomole per cubic metre bar |
| K61 | kilomole per minute |
| K62 | litre per litre |
| K63 | reciprocal litre |
| K64 | pound (avoirdupois) per degree Fahrenheit |
| K65 | pound (avoirdupois) square foot |
| K66 | pound (avoirdupois) per day |
| K67 | pound per foot hour |
| K68 | pound per foot second |
| K69 | pound (avoirdupois) per cubic foot degree Fahrenheit |
| K70 | pound (avoirdupois) per cubic foot psi |
| K71 | pound (avoirdupois) per gallon (UK) |
| K73 | pound (avoirdupois) per hour degree Fahrenheit |
| K74 | pound (avoirdupois) per hour psi |
| K75 | pound (avoirdupois) per cubic inch degree Fahrenheit |
| K76 | pound (avoirdupois) per cubic inch psi |
| K77 | pound (avoirdupois) per psi |
| K78 | pound (avoirdupois) per minute |
| K79 | pound (avoirdupois) per minute degree Fahrenheit |
| K80 | pound (avoirdupois) per minute psi |
| K81 | pound (avoirdupois) per second |
| K82 | pound (avoirdupois) per second degree Fahrenheit |
| K83 | pound (avoirdupois) per second psi |
| K84 | pound per cubic yard |
| K85 | pound-force per square foot |
| K86 | pound-force per square inch degree Fahrenheit |
| K87 | psi cubic inch per second |
| K88 | psi litre per second |
| K89 | psi cubic metre per second |
| K90 | psi cubic yard per second |
| K91 | pound-force second per square foot |
| K92 | pound-force second per square inch |
| K93 | reciprocal psi |
| K94 | quart (UK liquid) per day |
| K95 | quart (UK liquid) per hour |
| K96 | quart (UK liquid) per minute |
| K97 | quart (UK liquid) per second |
| K98 | quart (US liquid) per day |
| K99 | quart (US liquid) per hour |
| KA | cake |
| KAT | katal |
| KB | kilocharacter |
| KBA | kilobar |
| KCC | kilogram of choline chloride |
| KDW | kilogram drained net weight |
| KEL | kelvin |
| KGM | kilogram |
| KGS | kilogram per second |
| KHY | kilogram of hydrogen peroxide |
| KHZ | kilohertz |
| KI | kilogram per millimetre width |
| KIC | kilogram, including container |
| KIP | kilogram, including inner packaging |
| KJ | kilosegment |
| KJO | kilojoule |
| KL | kilogram per metre |
| KLK | lactic dry material percentage |
| KLX | kilolux |
| KMA | kilogram of methylamine |
| KMH | kilometre per hour |
| KMK | square kilometre |
| KMQ | kilogram per cubic metre |
| KMT | kilometre |
| KNI | kilogram of nitrogen |
| KNM | kilonewton per square metre |
| KNS | kilogram named substance |
| KNT | knot |
| KO | milliequivalence caustic potash per gram of product |
| KPA | kilopascal |
| KPH | kilogram of potassium hydroxide (caustic potash) |
| KPO | kilogram of potassium oxide |
| KPP | kilogram of phosphorus pentoxide (phosphoric anhydride) |
| KR | kiloroentgen |
| KSD | kilogram of substance 90 % dry |
| KSH | kilogram of sodium hydroxide (caustic soda) |
| KT | kit |
| KTN | kilotonne |
| KUR | kilogram of uranium |
| KVA | kilovolt - ampere |
| KVR | kilovar |
| KVT | kilovolt |
| KW | kilogram per millimetre |
| KWH | kilowatt hour |
| KWN | Kilowatt hour per normalized cubic metre |
| KWO | kilogram of tungsten trioxide |
| KWS | Kilowatt hour per standard cubic metre |
| KWT | kilowatt |
| KWY | kilowatt year |
| KX | millilitre per kilogram |
| L10 | quart (US liquid) per minute |
| L11 | quart (US liquid) per second |
| L12 | metre per second kelvin |
| L13 | metre per second bar |
| L14 | square metre hour degree Celsius per kilocalorie (international table) |
| L15 | millipascal second per kelvin |
| L16 | millipascal second per bar |
| L17 | milligram per cubic metre kelvin |
| L18 | milligram per cubic metre bar |
| L19 | millilitre per litre |
| L2 | litre per minute |
| L20 | reciprocal cubic millimetre |
| L21 | cubic millimetre per cubic metre |
| L23 | mole per hour |
| L24 | mole per kilogram kelvin |
| L25 | mole per kilogram bar |
| L26 | mole per litre kelvin |
| L27 | mole per litre bar |
| L28 | mole per cubic metre kelvin |
| L29 | mole per cubic metre bar |
| L30 | mole per minute |
| L31 | milliroentgen aequivalent men |
| L32 | nanogram per kilogram |
| L33 | ounce (avoirdupois) per day |
| L34 | ounce (avoirdupois) per hour |
| L35 | ounce (avoirdupois) per minute |
| L36 | ounce (avoirdupois) per second |
| L37 | ounce (avoirdupois) per gallon (UK) |
| L38 | ounce (avoirdupois) per gallon (US) |
| L39 | ounce (avoirdupois) per cubic inch |
| L40 | ounce (avoirdupois)-force |
| L41 | ounce (avoirdupois)-force inch |
| L42 | picosiemens per metre |
| L43 | peck (UK) |
| L44 | peck (UK) per day |
| L45 | peck (UK) per hour |
| L46 | peck (UK) per minute |
| L47 | peck (UK) per second |
| L48 | peck (US dry) per day |
| L49 | peck (US dry) per hour |
| L50 | peck (US dry) per minute |
| L51 | peck (US dry) per second |
| L52 | psi per psi |
| L53 | pint (UK) per day |
| L54 | pint (UK) per hour |
| L55 | pint (UK) per minute |
| L56 | pint (UK) per second |
| L57 | pint (US liquid) per day |
| L58 | pint (US liquid) per hour |
| L59 | pint (US liquid) per minute |
| L60 | pint (US liquid) per second |
| L63 | slug per day |
| L64 | slug per foot second |
| L65 | slug per cubic foot |
| L66 | slug per hour |
| L67 | slug per minute |
| L68 | slug per second |
| L69 | tonne per kelvin |
| L70 | tonne per bar |
| L71 | tonne per day |
| L72 | tonne per day kelvin |
| L73 | tonne per day bar |
| L74 | tonne per hour kelvin |
| L75 | tonne per hour bar |
| L76 | tonne per cubic metre kelvin |
| L77 | tonne per cubic metre bar |
| L78 | tonne per minute |
| L79 | tonne per minute kelvin |
| L80 | tonne per minute bar |
| L81 | tonne per second |
| L82 | tonne per second kelvin |
| L83 | tonne per second bar |
| L84 | ton (UK shipping) |
| L85 | ton long per day |
| L86 | ton (US shipping) |
| L87 | ton short per degree Fahrenheit |
| L88 | ton short per day |
| L89 | ton short per hour degree Fahrenheit |
| L90 | ton short per hour psi |
| L91 | ton short per psi |
| L92 | ton (UK long) per cubic yard |
| L93 | ton (US short) per cubic yard |
| L94 | ton-force (US short) |
| L95 | common year |
| L96 | sidereal year |
| L98 | yard per degree Fahrenheit |
| L99 | yard per psi |
| LA | pound per cubic inch |
| LAC | lactose excess percentage |
| LBR | pound |
| LBT | troy pound (US) |
| LD | litre per day |
| LEF | leaf |
| LF | linear foot |
| LH | labour hour |
| LK | link |
| LM | linear metre |
| LN | length |
| LO | lot [unit of procurement] |
| LP | liquid pound |
| LPA | litre of pure alcohol |
| LR | layer |
| LS | lump sum |
| LTN | ton (UK) or long ton (US) |
| LTR | litre |
| LUB | metric ton, lubricating oil |
| LUM | lumen |
| LUX | lux |
| LY | linear yard |
| M1 | milligram per litre |
| M10 | reciprocal cubic yard |
| M11 | cubic yard per degree Fahrenheit |
| M12 | cubic yard per day |
| M13 | cubic yard per hour |
| M14 | cubic yard per psi |
| M15 | cubic yard per minute |
| M16 | cubic yard per second |
| M17 | kilohertz metre |
| M18 | gigahertz metre |
| M19 | Beaufort |
| M20 | reciprocal megakelvin or megakelvin to the power minus one |
| M21 | reciprocal kilovolt - ampere reciprocal hour |
| M22 | millilitre per square centimetre minute |
| M23 | newton per centimetre |
| M24 | ohm kilometre |
| M25 | percent per degree Celsius |
| M26 | gigaohm per metre |
| M27 | megahertz metre |
| M29 | kilogram per kilogram |
| M30 | reciprocal volt - ampere reciprocal second |
| M31 | kilogram per kilometre |
| M32 | pascal second per litre |
| M33 | millimole per litre |
| M34 | newton metre per square metre |
| M35 | millivolt - ampere |
| M36 | 30-day month |
| M37 | actual/360 |
| M38 | kilometre per second squared |
| M39 | centimetre per second squared |
| M4 | monetary value |
| M40 | yard per second squared |
| M41 | millimetre per second squared |
| M42 | mile (statute mile) per second squared |
| M43 | mil |
| M44 | revolution |
| M45 | degree [unit of angle] per second squared |
| M46 | revolution per minute |
| M47 | circular mil |
| M48 | square mile (based on U.S. survey foot) |
| M49 | chain (based on U.S. survey foot) |
| M5 | microcurie |
| M50 | furlong |
| M51 | foot (U.S. survey) |
| M52 | mile (based on U.S. survey foot) |
| M53 | metre per pascal |
| M55 | metre per radiant |
| M56 | shake |
| M57 | mile per minute |
| M58 | mile per second |
| M59 | metre per second pascal |
| M60 | metre per hour |
| M61 | inch per year |
| M62 | kilometre per second |
| M63 | inch per minute |
| M64 | yard per second |
| M65 | yard per minute |
| M66 | yard per hour |
| M67 | acre-foot (based on U.S. survey foot) |
| M68 | cord (128 ft3) |
| M69 | cubic mile (UK statute) |
| M7 | micro-inch |
| M70 | ton, register |
| M71 | cubic metre per pascal |
| M72 | bel |
| M73 | kilogram per cubic metre pascal |
| M74 | kilogram per pascal |
| M75 | kilopound-force |
| M76 | poundal |
| M77 | kilogram metre per second squared |
| M78 | pond |
| M79 | square foot per hour |
| M80 | stokes per pascal |
| M81 | square centimetre per second |
| M82 | square metre per second pascal |
| M83 | denier |
| M84 | pound per yard |
| M85 | ton, assay |
| M86 | pfund |
| M87 | kilogram per second pascal |
| M88 | tonne per month |
| M89 | tonne per year |
| M9 | million Btu per 1000 cubic foot |
| M90 | kilopound per hour |
| M91 | pound per pound |
| M92 | pound-force foot |
| M93 | newton metre per radian |
| M94 | kilogram metre |
| M95 | poundal foot |
| M96 | poundal inch |
| M97 | dyne metre |
| M98 | kilogram centimetre per second |
| M99 | gram centimetre per second |
| MAH | megavolt ampere reactive hour |
| MAL | megalitre |
| MAM | megametre |
| MAR | megavar |
| MAW | megawatt |
| MBE | thousand standard brick equivalent |
| MBF | thousand board foot |
| MBR | millibar |
| MC | microgram |
| MCU | millicurie |
| MD | air dry metric ton |
| MGM | milligram |
| MHZ | megahertz |
| MIK | square mile (statute mile) |
| MIL | thousand |
| MIN | minute [unit of time] |
| MIO | million |
| MIU | million international unit |
| MKD | Square Metre Day |
| MKM | Square Metre Month |
| MKW | Square Metre Week |
| MLD | milliard |
| MLT | millilitre |
| MMK | square millimetre |
| MMQ | cubic millimetre |
| MMT | millimetre |
| MND | kilogram, dry weight |
| MNJ | Mega Joule per Normalised cubic Metre |
| MON | month |
| MPA | megapascal |
| MQD | Cubic Metre Day |
| MQH | cubic metre per hour |
| MQM | Cubic Metre Month |
| MQS | cubic metre per second |
| MQW | Cubic Metre Week |
| MRD | Metre Day |
| MRM | Metre Month |
| MRW | Metre Week |
| MSK | metre per second squared |
| MTK | square metre |
| MTQ | cubic metre |
| MTR | metre |
| MTS | metre per second |
| MTZ | milihertz |
| MVA | megavolt - ampere |
| MWH | megawatt hour (1000  kW.h) |
| N1 | pen calorie |
| N10 | pound foot per second |
| N11 | pound inch per second |
| N12 | Pferdestaerke |
| N13 | centimetre of mercury (0 ºC) |
| N14 | centimetre of water (4 ºC) |
| N15 | foot of water (39.2 ºF) |
| N16 | inch of mercury (32 ºF) |
| N17 | inch of mercury (60 ºF) |
| N18 | inch of water (39.2 ºF) |
| N19 | inch of water (60 ºF) |
| N20 | kip per square inch |
| N21 | poundal per square foot |
| N22 | ounce (avoirdupois) per square inch |
| N23 | conventional metre of water |
| N24 | gram per square millimetre |
| N25 | pound per square yard |
| N26 | poundal per square inch |
| N27 | foot to the fourth power |
| N28 | cubic decimetre per kilogram |
| N29 | cubic foot per pound |
| N3 | print point |
| N30 | cubic inch per pound |
| N31 | kilonewton per metre |
| N32 | poundal per inch |
| N33 | pound-force per yard |
| N34 | poundal second per square foot |
| N35 | poise per pascal |
| N36 | newton second per square metre |
| N37 | kilogram per metre second |
| N38 | kilogram per metre minute |
| N39 | kilogram per metre day |
| N40 | kilogram per metre hour |
| N41 | gram per centimetre second |
| N42 | poundal second per square inch |
| N43 | pound per foot minute |
| N44 | pound per foot day |
| N45 | cubic metre per second pascal |
| N46 | foot poundal |
| N47 | inch poundal |
| N48 | watt per square centimetre |
| N49 | watt per square inch |
| N50 | British thermal unit (international table) per square foot hour |
| N51 | British thermal unit (thermochemical) per square foot hour |
| N52 | British thermal unit (thermochemical) per square foot minute |
| N53 | British thermal unit (international table) per square foot second |
| N54 | British thermal unit (thermochemical) per square foot second |
| N55 | British thermal unit (international table) per square inch second |
| N56 | calorie (thermochemical) per square centimetre minute |
| N57 | calorie (thermochemical) per square centimetre second |
| N58 | British thermal unit (international table) per cubic foot |
| N59 | British thermal unit (thermochemical) per cubic foot |
| N60 | British thermal unit (international table) per degree Fahrenheit |
| N61 | British thermal unit (thermochemical) per degree Fahrenheit |
| N62 | British thermal unit (international table) per degree Rankine |
| N63 | British thermal unit (thermochemical) per degree Rankine |
| N64 | British thermal unit (thermochemical) per pound degree Rankine |
| N65 | kilocalorie (international table) per gram kelvin |
| N66 | British thermal unit (39 ºF) |
| N67 | British thermal unit (59 ºF) |
| N68 | British thermal unit (60 ºF) |
| N69 | calorie (20 ºC) |
| N70 | quad (1015 BtuIT) |
| N71 | therm (EC) |
| N72 | therm (U.S.) |
| N73 | British thermal unit (thermochemical) per pound |
| N74 | British thermal unit (international table) per hour square foot degree Fahrenheit |
| N75 | British thermal unit (thermochemical) per hour square foot degree Fahrenheit |
| N76 | British thermal unit (international table) per second square foot degree Fahrenheit |
| N77 | British thermal unit (thermochemical) per second square foot degree Fahrenheit |
| N78 | kilowatt per square metre kelvin |
| N79 | kelvin per pascal |
| N80 | watt per metre degree Celsius |
| N81 | kilowatt per metre kelvin |
| N82 | kilowatt per metre degree Celsius |
| N83 | metre per degree Celcius metre |
| N84 | degree Fahrenheit hour per British thermal unit (international table) |
| N85 | degree Fahrenheit hour per British thermal unit (thermochemical) |
| N86 | degree Fahrenheit second per British thermal unit (international table) |
| N87 | degree Fahrenheit second per British thermal unit (thermochemical) |
| N88 | degree Fahrenheit hour square foot per British thermal unit (international table) inch |
| N89 | degree Fahrenheit hour square foot per British thermal unit (thermochemical) inch |
| N90 | kilofarad |
| N91 | reciprocal joule |
| N92 | picosiemens |
| N93 | ampere per pascal |
| N94 | franklin |
| N95 | ampere minute |
| N96 | biot |
| N97 | gilbert |
| N98 | volt per pascal |
| N99 | picovolt |
| NA | milligram per kilogram |
| NAR | number of articles |
| NCL | number of cells |
| NEW | newton |
| NF | message |
| NIL | nil |
| NIU | number of international units |
| NL | load |
| NM3 | Normalised cubic metre |
| NMI | nautical mile |
| NMP | number of packs |
| NPT | number of parts |
| NT | net ton |
| NTU | Nephelometric turbidity unit |
| NU | newton metre |
| NX | part per thousand |
| OA | panel |
| ODE | ozone depletion equivalent |
| ODG | ODS Grams |
| ODK | ODS Kilograms |
| ODM | ODS Milligrams |
| OHM | ohm |
| ON | ounce per square yard |
| ONZ | ounce (avoirdupois) |
| OPM | oscillations per minute |
| OT | overtime hour |
| OZA | fluid ounce (US) |
| OZI | fluid ounce (UK) |
| P1 | percent |
| P10 | coulomb per metre |
| P11 | kiloweber |
| P12 | gamma |
| P13 | kilotesla |
| P14 | joule per second |
| P15 | joule per minute |
| P16 | joule per hour |
| P17 | joule per day |
| P18 | kilojoule per second |
| P19 | kilojoule per minute |
| P2 | pound per foot |
| P20 | kilojoule per hour |
| P21 | kilojoule per day |
| P22 | nanoohm |
| P23 | ohm circular-mil per foot |
| P24 | kilohenry |
| P25 | lumen per square foot |
| P26 | phot |
| P27 | footcandle |
| P28 | candela per square inch |
| P29 | footlambert |
| P30 | lambert |
| P31 | stilb |
| P32 | candela per square foot |
| P33 | kilocandela |
| P34 | millicandela |
| P35 | Hefner-Kerze |
| P36 | international candle |
| P37 | British thermal unit (international table) per square foot |
| P38 | British thermal unit (thermochemical) per square foot |
| P39 | calorie (thermochemical) per square centimetre |
| P40 | langley |
| P41 | decade (logarithmic) |
| P42 | pascal squared second |
| P43 | bel per metre |
| P44 | pound mole |
| P45 | pound mole per second |
| P46 | pound mole per minute |
| P47 | kilomole per kilogram |
| P48 | pound mole per pound |
| P49 | newton square metre per ampere |
| P5 | five pack |
| P50 | weber metre |
| P51 | mol per kilogram pascal |
| P52 | mol per cubic metre pascal |
| P53 | unit pole |
| P54 | milligray per second |
| P55 | microgray per second |
| P56 | nanogray per second |
| P57 | gray per minute |
| P58 | milligray per minute |
| P59 | microgray per minute |
| P60 | nanogray per minute |
| P61 | gray per hour |
| P62 | milligray per hour |
| P63 | microgray per hour |
| P64 | nanogray per hour |
| P65 | sievert per second |
| P66 | millisievert per second |
| P67 | microsievert per second |
| P68 | nanosievert per second |
| P69 | rem per second |
| P70 | sievert per hour |
| P71 | millisievert per hour |
| P72 | microsievert per hour |
| P73 | nanosievert per hour |
| P74 | sievert per minute |
| P75 | millisievert per minute |
| P76 | microsievert per minute |
| P77 | nanosievert per minute |
| P78 | reciprocal square inch |
| P79 | pascal square metre per kilogram |
| P80 | millipascal per metre |
| P81 | kilopascal per metre |
| P82 | hectopascal per metre |
| P83 | standard atmosphere per metre |
| P84 | technical atmosphere per metre |
| P85 | torr per metre |
| P86 | psi per inch |
| P87 | cubic metre per second square metre |
| P88 | rhe |
| P89 | pound-force foot per inch |
| P90 | pound-force inch per inch |
| P91 | perm (0 ºC) |
| P92 | perm (23 ºC) |
| P93 | byte per second |
| P94 | kilobyte per second |
| P95 | megabyte per second |
| P96 | reciprocal volt |
| P97 | reciprocal radian |
| P98 | pascal to the power sum of stoichiometric numbers |
| P99 | mole per cubiv metre to the power sum of stoichiometric numbers |
| PAL | pascal |
| PD | pad |
| PFL | proof litre |
| PGL | proof gallon |
| PI | pitch |
| PLA | degree Plato |
| PO | pound per inch of length |
| PQ | page per inch |
| PR | pair |
| PS | pound-force per square inch |
| PTD | dry pint (US) |
| PTI | pint (UK) |
| PTL | liquid pint (US) |
| PTN | portion |
| Q10 | joule per tesla |
| Q11 | erlang |
| Q12 | octet |
| Q13 | octet per second |
| Q14 | shannon |
| Q15 | hartley |
| Q16 | natural unit of information |
| Q17 | shannon per second |
| Q18 | hartley per second |
| Q19 | natural unit of information per second |
| Q20 | second per kilogramm |
| Q21 | watt square metre |
| Q22 | second per radian cubic metre |
| Q23 | weber to the power minus one |
| Q24 | reciprocal inch |
| Q25 | dioptre |
| Q26 | one per one |
| Q27 | newton metre per metre |
| Q28 | kilogram per square metre pascal second |
| Q29 | microgram per hectogram |
| Q3 | meal |
| Q30 | pH (potential of Hydrogen) |
| Q31 | kilojoule per gram |
| Q32 | femtolitre |
| Q33 | picolitre |
| Q34 | nanolitre |
| Q35 | megawatts per minute |
| Q36 | square metre per cubic metre |
| Q37 | Standard cubic metre per day |
| Q38 | Standard cubic metre per hour |
| Q39 | Normalized cubic metre per day |
| Q40 | Normalized cubic metre per hour |
| Q41 | Joule per normalised cubic metre |
| Q42 | Joule per standard cubic metre |
| QA | page - facsimile |
| QAN | quarter (of a year) |
| QB | page - hardcopy |
| QR | quire |
| QTD | dry quart (US) |
| QTI | quart (UK) |
| QTL | liquid quart (US) |
| QTR | quarter (UK) |
| R1 | pica |
| R9 | thousand cubic metre |
| RH | running or operating hour |
| RM | ream |
| ROM | room |
| RP | pound per ream |
| RPM | revolutions per minute |
| RPS | revolutions per second |
| RT | revenue ton mile |
| S3 | square foot per second |
| S4 | square metre per second |
| SAN | half year (6 months) |
| SCO | score |
| SCR | scruple |
| SEC | second [unit of time] |
| SET | set |
| SG | segment |
| SIE | siemens |
| SM3 | Standard cubic metre |
| SMI | mile (statute mile) |
| SQ | square |
| SQR | square, roofing |
| SR | strip |
| STC | stick |
| STI | stone (UK) |
| STK | stick, cigarette |
| STL | standard litre |
| STN | ton (US) or short ton (UK/US) |
| STW | straw |
| SW | skein |
| SX | shipment |
| SYR | syringe |
| T0 | telecommunication line in service |
| T3 | thousand piece |
| TAH | kiloampere hour (thousand ampere hour) |
| TAN | total acid number |
| TI | thousand square inch |
| TIC | metric ton, including container |
| TIP | metric ton, including inner packaging |
| TKM | tonne kilometre |
| TMS | kilogram of imported meat, less offal |
| TNE | tonne (metric ton) |
| TP | ten pack |
| TPI | teeth per inch |
| TPR | ten pair |
| TQD | thousand cubic metre per day |
| TRL | trillion (EUR) |
| TST | ten set |
| TTS | ten thousand sticks |
| U1 | treatment |
| U2 | tablet |
| UB | telecommunication line in service average |
| UC | telecommunication port |
| VA | volt - ampere per kilogram |
| VLT | volt |
| VP | percent volume |
| W2 | wet kilo |
| WA | watt per kilogram |
| WB | wet pound |
| WCD | cord |
| WE | wet ton |
| WEB | weber |
| WEE | week |
| WG | wine gallon |
| WHR | watt hour |
| WM | working month |
| WSD | standard |
| WTT | watt |
| X1 | Gunter's chain |
| YDK | square yard |
| YDQ | cubic yard |
| YRD | yard |
| Z11 | hanging container |
| Z9 | nanomole |
| ZP | page |
| ZZ | mutually defined |
| X1A | Drum, steel |
| X1B | Drum, aluminium |
| X1D | Drum, plywood |
| X1F | Container, flexible |
| X1G | Drum, fibre |
| X1W | Drum, wooden |
| X2C | Barrel, wooden |
| X3A | Jerrican, steel |
| X3H | Jerrican, plastic |
| X43 | Bag, super bulk |
| X44 | Bag, polybag |
| X4A | Box, steel |
| X4B | Box, aluminium |
| X4C | Box, natural wood |
| X4D | Box, plywood |
| X4F | Box, reconstituted wood |
| X4G | Box, fibreboard |
| X4H | Box, plastic |
| X5H | Bag, woven plastic |
| X5L | Bag, textile |
| X5M | Bag, paper |
| X6H | Composite packaging, plastic receptacle |
| X6P | Composite packaging, glass receptacle |
| X7A | Case, car |
| X7B | Case, wooden |
| X8A | Pallet, wooden |
| X8B | Crate, wooden |
| X8C | Bundle, wooden |
| XAA | Intermediate bulk container, rigid plastic |
| XAB | Receptacle, fibre |
| XAC | Receptacle, paper |
| XAD | Receptacle, wooden |
| XAE | Aerosol |
| XAF | Pallet, modular, collars 80cms \* 60cms |
| XAG | Pallet, shrinkwrapped |
| XAH | Pallet, 100cms \* 110cms |
| XAI | Clamshell |
| XAJ | Cone |
| XAL | Ball |
| XAM | Ampoule, non-protected |
| XAP | Ampoule, protected |
| XAT | Atomizer |
| XAV | Capsule |
| XB4 | Belt |
| XBA | Barrel |
| XBB | Bobbin |
| XBC | Bottlecrate / bottlerack |
| XBD | Board |
| XBE | Bundle |
| XBF | Balloon, non-protected |
| XBG | Bag |
| XBH | Bunch |
| XBI | Bin |
| XBJ | Bucket |
| XBK | Basket |
| XBL | Bale, compressed |
| XBM | Basin |
| XBN | Bale, non-compressed |
| XBO | Bottle, non-protected, cylindrical |
| XBP | Balloon, protected |
| XBQ | Bottle, protected cylindrical |
| XBR | Bar |
| XBS | Bottle, non-protected, bulbous |
| XBT | Bolt |
| XBU | Butt |
| XBV | Bottle, protected bulbous |
| XBW | Box, for liquids |
| XBX | Box |
| XBY | Board, in bundle/bunch/truss |
| XBZ | Bars, in bundle/bunch/truss |
| XCA | Can, rectangular |
| XCB | Crate, beer |
| XCC | Churn |
| XCD | Can, with handle and spout |
| XCE | Creel |
| XCF | Coffer |
| XCG | Cage |
| XCH | Chest |
| XCI | Canister |
| XCJ | Coffin |
| XCK | Cask |
| XCL | Coil |
| XCM | Card |
| XCN | Container, not otherwise specified as transport equipment |
| XCO | Carboy, non-protected |
| XCP | Carboy, protected |
| XCQ | Cartridge |
| XCR | Crate |
| XCS | Case |
| XCT | Carton |
| XCU | Cup |
| XCV | Cover |
| XCW | Cage, roll |
| XCX | Can, cylindrical |
| XCY | Cylinder |
| XCZ | Canvas |
| XDA | Crate, multiple layer, plastic |
| XDB | Crate, multiple layer, wooden |
| XDC | Crate, multiple layer, cardboard |
| XDG | Cage, Commonwealth Handling Equipment Pool (CHEP) |
| XDH | Box, Commonwealth Handling Equipment Pool (CHEP), Eurobox |
| XDI | Drum, iron |
| XDJ | Demijohn, non-protected |
| XDK | Crate, bulk, cardboard |
| XDL | Crate, bulk, plastic |
| XDM | Crate, bulk, wooden |
| XDN | Dispenser |
| XDP | Demijohn, protected |
| XDR | Drum |
| XDS | Tray, one layer no cover, plastic |
| XDT | Tray, one layer no cover, wooden |
| XDU | Tray, one layer no cover, polystyrene |
| XDV | Tray, one layer no cover, cardboard |
| XDW | Tray, two layers no cover, plastic tray |
| XDX | Tray, two layers no cover, wooden |
| XDY | Tray, two layers no cover, cardboard |
| XEC | Bag, plastic |
| XED | Case, with pallet base |
| XEE | Case, with pallet base, wooden |
| XEF | Case, with pallet base, cardboard |
| XEG | Case, with pallet base, plastic |
| XEH | Case, with pallet base, metal |
| XEI | Case, isothermic |
| XEN | Envelope |
| XFB | Flexibag |
| XFC | Crate, fruit |
| XFD | Crate, framed |
| XFE | Flexitank |
| XFI | Firkin |
| XFL | Flask |
| XFO | Footlocker |
| XFP | Filmpack |
| XFR | Frame |
| XFT | Foodtainer |
| XFW | Cart, flatbed |
| XFX | Bag, flexible container |
| XGB | Bottle, gas |
| XGI | Girder |
| XGL | Container, gallon |
| XGR | Receptacle, glass |
| XGU | Tray, containing horizontally stacked flat items |
| XGY | Bag, gunny |
| XGZ | Girders, in bundle/bunch/truss |
| XHA | Basket, with handle, plastic |
| XHB | Basket, with handle, wooden |
| XHC | Basket, with handle, cardboard |
| XHG | Hogshead |
| XHN | Hanger |
| XHR | Hamper |
| XIA | Package, display, wooden |
| XIB | Package, display, cardboard |
| XIC | Package, display, plastic |
| XID | Package, display, metal |
| XIE | Package, show |
| XIF | Package, flow |
| XIG | Package, paper wrapped |
| XIH | Drum, plastic |
| XIK | Package, cardboard, with bottle grip-holes |
| XIL | Tray, rigid, lidded stackable (CEN TS 14482:2002) |
| XIN | Ingot |
| XIZ | Ingots, in bundle/bunch/truss |
| XJB | Bag, jumbo |
| XJC | Jerrican, rectangular |
| XJG | Jug |
| XJR | Jar |
| XJT | Jutebag |
| XJY | Jerrican, cylindrical |
| XKG | Keg |
| XKI | Kit |
| XLE | Luggage |
| XLG | Log |
| XLT | Lot |
| XLU | Lug |
| XLV | Liftvan |
| XLZ | Logs, in bundle/bunch/truss |
| XMA | Crate, metal |
| XMB | Bag, multiply |
| XMC | Crate, milk |
| XME | Container, metal |
| XMR | Receptacle, metal |
| XMS | Sack, multi-wall |
| XMT | Mat |
| XMW | Receptacle, plastic wrapped |
| XMX | Matchbox |
| XNA | Not available |
| XNE | Unpacked or unpackaged |
| XNF | Unpacked or unpackaged, single unit |
| XNG | Unpacked or unpackaged, multiple units |
| XNS | Nest |
| XNT | Net |
| XNU | Net, tube, plastic |
| XNV | Net, tube, textile |
| XO1 | Two sided cage on wheels with fixing strap |
| XO2 | Trolley |
| XO3 | Oneway pallet ISO 0 - 1/2 EURO Pallet |
| XO4 | Oneway pallet ISO 1 - 1/1 EURO Pallet |
| XO5 | Oneway pallet ISO 2 - 2/1 EURO Pallet |
| XO6 | Pallet with exceptional dimensions |
| XO7 | Wooden pallet  40 cm x 80 cm |
| XO8 | Plastic pallet SRS 60 cm x 80 cm |
| XO9 | Plastic pallet SRS 80 cm x 120 cm |
| XOA | Pallet, CHEP 40 cm x 60 cm |
| XOB | Pallet, CHEP 80 cm x 120 cm |
| XOC | Pallet, CHEP 100 cm x 120 cm |
| XOD | Pallet, AS 4068-1993 |
| XOE | Pallet, ISO T11 |
| XOF | Platform, unspecified weight or dimension |
| XOG | Pallet ISO 0 - 1/2 EURO Pallet |
| XOH | Pallet ISO 1 - 1/1 EURO Pallet |
| XOI | Pallet ISO 2 – 2/1 EURO Pallet |
| XOJ | 1/4 EURO Pallet |
| XOK | Block |
| XOL | 1/8 EURO Pallet |
| XOM | Synthetic pallet ISO 1 |
| XON | Synthetic pallet ISO 2 |
| XOP | Wholesaler pallet |
| XOQ | Pallet 80 X 100 cm |
| XOR | Pallet 60 X 100 cm |
| XOS | Oneway pallet |
| XOT | Octabin |
| XOU | Container, outer |
| XOV | Returnable pallet |
| XOW | Large bag, pallet sized |
| XOX | A wheeled pallet with raised rim (81 x 67 x 135) |
| XOY | A Wheeled pallet with raised rim (81 x 72 x 135) |
| XOZ | Wheeled pallet with raised rim ( 81 x 60 x 16) |
| XP1 | CHEP pallet 60 cm x 80 cm |
| XP2 | Pan |
| XP3 | LPR pallet 60 cm x 80 cm |
| XP4 | LPR pallet 80 cm x 120 cm |
| XPA | Packet |
| XPB | Pallet, box Combined open-ended box and pallet |
| XPC | Parcel |
| XPD | Pallet, modular, collars 80cms \* 100cms |
| XPE | Pallet, modular, collars 80cms \* 120cms |
| XPF | Pen |
| XPG | Plate |
| XPH | Pitcher |
| XPI | Pipe |
| XPJ | Punnet |
| XPK | Package |
| XPL | Pail |
| XPN | Plank |
| XPO | Pouch |
| XPP | Piece |
| XPR | Receptacle, plastic |
| XPT | Pot |
| XPU | Tray |
| XPV | Pipes, in bundle/bunch/truss |
| XPX | Pallet |
| XPY | Plates, in bundle/bunch/truss |
| XPZ | Planks, in bundle/bunch/truss |
| XQA | Drum, steel, non-removable head |
| XQB | Drum, steel, removable head |
| XQC | Drum, aluminium, non-removable head |
| XQD | Drum, aluminium, removable head |
| XQF | Drum, plastic, non-removable head |
| XQG | Drum, plastic, removable head |
| XQH | Barrel, wooden, bung type |
| XQJ | Barrel, wooden, removable head |
| XQK | Jerrican, steel, non-removable head |
| XQL | Jerrican, steel, removable head |
| XQM | Jerrican, plastic, non-removable head |
| XQN | Jerrican, plastic, removable head |
| XQP | Box, wooden, natural wood, ordinary |
| XQQ | Box, wooden, natural wood, with sift proof walls |
| XQR | Box, plastic, expanded |
| XQS | Box, plastic, solid |
| XRD | Rod |
| XRG | Ring |
| XRJ | Rack, clothing hanger |
| XRK | Rack |
| XRL | Reel |
| XRO | Roll |
| XRT | Rednet |
| XRZ | Rods, in bundle/bunch/truss |
| XSA | Sack |
| XSB | Slab |
| XSC | Crate, shallow |
| XSD | Spindle |
| XSE | Sea-chest |
| XSH | Sachet |
| XSI | Skid |
| XSK | Case, skeleton |
| XSL | Slipsheet |
| XSM | Sheetmetal |
| XSO | Spool |
| XSP | Sheet, plastic wrapping |
| XSS | Case, steel |
| XST | Sheet |
| XSU | Suitcase |
| XSV | Envelope, steel |
| XSW | Shrinkwrapped |
| XSX | Set |
| XSY | Sleeve |
| XSZ | Sheets, in bundle/bunch/truss |
| XT1 | Tablet |
| XTB | Tub |
| XTC | Tea-chest |
| XTD | Tube, collapsible |
| XTE | Tyre |
| XTG | Tank container, generic |
| XTI | Tierce |
| XTK | Tank, rectangular |
| XTL | Tub, with lid |
| XTN | Tin |
| XTO | Tun |
| XTR | Trunk |
| XTS | Truss |
| XTT | Bag, tote |
| XTU | Tube |
| XTV | Tube, with nozzle |
| XTW | Pallet, triwall |
| XTY | Tank, cylindrical |
| XTZ | Tubes, in bundle/bunch/truss |
| XUC | Uncaged |
| XUN | Unit |
| XVA | Vat |
| XVG | Bulk, gas (at 1031 mbar and 15°C) |
| XVI | Vial |
| XVK | Vanpack |
| XVL | Bulk, liquid |
| XVN | Vehicle |
| XVO | Bulk, solid, large particles ("nodules") |
| XVP | Vacuum-packed |
| XVQ | Bulk, liquefied gas (at abnormal temperature/pressure) |
| XVR | Bulk, solid, granular particles ("grains") |
| XVS | Bulk, scrap metal |
| XVY | Bulk, solid, fine particles ("powders") |
| XWA | Intermediate bulk container |
| XWB | Wickerbottle |
| XWC | Intermediate bulk container, steel |
| XWD | Intermediate bulk container, aluminium |
| XWF | Intermediate bulk container, metal |
| XWG | Intermediate bulk container, steel, pressurised > 10 kpa |
| XWH | Intermediate bulk container, aluminium, pressurised > 10 kpa |
| XWJ | Intermediate bulk container, metal, pressure 10 kpa |
| XWK | Intermediate bulk container, steel, liquid |
| XWL | Intermediate bulk container, aluminium, liquid |
| XWM | Intermediate bulk container, metal, liquid |
| XWN | Intermediate bulk container, woven plastic, without coat/liner |
| XWP | Intermediate bulk container, woven plastic, coated |
| XWQ | Intermediate bulk container, woven plastic, with liner |
| XWR | Intermediate bulk container, woven plastic, coated and liner |
| XWS | Intermediate bulk container, plastic film |
| XWT | Intermediate bulk container, textile with out coat/liner |
| XWU | Intermediate bulk container, natural wood, with inner liner |
| XWV | Intermediate bulk container, textile, coated |
| XWW | Intermediate bulk container, textile, with liner |
| XWX | Intermediate bulk container, textile, coated and liner |
| XWY | Intermediate bulk container, plywood, with inner liner |
| XWZ | Intermediate bulk container, reconstituted wood, with inner liner |
| XXA | Bag, woven plastic, without inner coat/liner |
| XXB | Bag, woven plastic, sift proof |
| XXC | Bag, woven plastic, water resistant |
| XXD | Bag, plastics film |
| XXF | Bag, textile, without inner coat/liner |
| XXG | Bag, textile, sift proof |
| XXH | Bag, textile, water resistant |
| XXJ | Bag, paper, multi-wall |
| XXK | Bag, paper, multi-wall, water resistant |
| XYA | Composite packaging, plastic receptacle in steel drum |
| XYB | Composite packaging, plastic receptacle in steel crate box |
| XYC | Composite packaging, plastic receptacle in aluminium drum |
| XYD | Composite packaging, plastic receptacle in aluminium crate |
| XYF | Composite packaging, plastic receptacle in wooden box |
| XYG | Composite packaging, plastic receptacle in plywood drum |
| XYH | Composite packaging, plastic receptacle in plywood box |
| XYJ | Composite packaging, plastic receptacle in fibre drum |
| XYK | Composite packaging, plastic receptacle in fibreboard box |
| XYL | Composite packaging, plastic receptacle in plastic drum |
| XYM | Composite packaging, plastic receptacle in solid plastic box |
| XYN | Composite packaging, glass receptacle in steel drum |
| XYP | Composite packaging, glass receptacle in steel crate box |
| XYQ | Composite packaging, glass receptacle in aluminium drum |
| XYR | Composite packaging, glass receptacle in aluminium crate |
| XYS | Composite packaging, glass receptacle in wooden box |
| XYT | Composite packaging, glass receptacle in plywood drum |
| XYV | Composite packaging, glass receptacle in wickerwork hamper |
| XYW | Composite packaging, glass receptacle in fibre drum |
| XYX | Composite packaging, glass receptacle in fibreboard box |
| XYY | Composite packaging, glass receptacle in expandable plastic pack |
| XYZ | Composite packaging, glass receptacle in solid plastic pack |
| XZA | Intermediate bulk container, paper, multi-wall |
| XZB | Bag, large |
| XZC | Intermediate bulk container, paper, multi-wall, water resistant |
| XZD | Intermediate bulk container, rigid plastic, with structural equipment, solids |
| XZF | Intermediate bulk container, rigid plastic, freestanding, solids |
| XZG | Intermediate bulk container, rigid plastic, with structural equipment, pressurised |
| XZH | Intermediate bulk container, rigid plastic, freestanding, pressurised |
| XZJ | Intermediate bulk container, rigid plastic, with structural equipment, liquids |
| XZK | Intermediate bulk container, rigid plastic, freestanding, liquids |
| XZL | Intermediate bulk container, composite, rigid plastic, solids |
| XZM | Intermediate bulk container, composite, flexible plastic, solids |
| XZN | Intermediate bulk container, composite, rigid plastic, pressurised |
| XZP | Intermediate bulk container, composite, flexible plastic, pressurised |
| XZQ | Intermediate bulk container, composite, rigid plastic, liquids |
| XZR | Intermediate bulk container, composite, flexible plastic, liquids |
| XZS | Intermediate bulk container, composite |
| XZT | Intermediate bulk container, fibreboard |
| XZU | Intermediate bulk container, flexible |
| XZV | Intermediate bulk container, metal, other than steel |
| XZW | Intermediate bulk container, natural wood |
| XZX | Intermediate bulk container, plywood |
| XZY | Intermediate bulk container, reconstituted wood |
| XZZ | Mutually defined |

# File Download

* [Download JSON file](../10-sample-documents/samples/UnitTypes.json) containing definition of all the unit types.

# Additional Considerations

* Relevant unit type should be provided during submitting the documents.

[Codes](README.md)


---
