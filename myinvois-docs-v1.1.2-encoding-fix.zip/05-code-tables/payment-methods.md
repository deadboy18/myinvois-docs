<!-- source: https://sdk.myinvois.hasil.gov.my/codes/payment-methods/ -->

# Payment Modes

Payment Mode refers to the chosen mechanism through which funds are transferred from buyer to supplier.

[Codes](README.md)

# Overview

Payment Mode that may be selected at the time of document submission.

# List

| Code | Description |
| --- | --- |
| 01 | Cash |
| 02 | Cheque |
| 03 | Bank Transfer |
| 04 | Credit Card |
| 05 | Debit Card |
| 06 | e-Wallet / Digital Wallet |
| 07 | Digital Bank |
| 08 | Others |

# File Download

[Download JSON file](../10-sample-documents/samples/PaymentMethods.json) containing codes of all the payment modes.

# Additional Considerations

Note that when submitting the documents, taxpayers should be using the code values.

[Codes](README.md)


---
