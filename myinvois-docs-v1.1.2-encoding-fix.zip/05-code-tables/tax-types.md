<!-- source: https://sdk.myinvois.hasil.gov.my/codes/tax-types/ -->

# Tax Types

List of tax types allowed as part of the document and submission.

[Codes](README.md)

# Overview

Tax types are used when entering tax information as part of the invoice (where applicable).

# List

## Taxable Types

| Code | Description |
| --- | --- |
| 01 | Sales Tax |
| 02 | Service Tax |
| 03 | Tourism Tax |
| 04 | High-Value Goods Tax |
| 05 | Sales Tax on Low Value Goods |
| 06 | Not Applicable |
| E | Tax exemption (where applicable) |

# File Download

* [Download JSON file](../10-sample-documents/samples/TaxTypes.json) containing definition of all the taxable types.

# Additional Considerations

* Relevant tax type should be provided during submitting the documents.

[Codes](README.md)


---
